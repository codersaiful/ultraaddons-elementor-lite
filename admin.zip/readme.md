![UltraAddons Elementor Lit](https://raw.githubusercontent.com/codersaiful/ultraaddons-elementor-lite/master/assets/images/svg/full-color-logo.svg)

# UltraAddons Elementor Lite

*UltraAddons Elementor Lite* has some Unique features and Ready made Widget. By using this plugin, You able to create a Full web site just by drag and drop.

## Features

* Many Ready widget,
* Drag and Drop
* Wrapper Link for any section, column, widget.
* Hover any animation for any section, column, widget.
* Advance Heading/Title with customize color, Typography
* Advance Button with customize color, Typography
* Advance Slider Slider
* Slider with Any content. Dynamic content.
* Slider with Pre-build Template of Elementor

Elementor Addons Plugin. Build your desired page just few click. Easy to use and useable for any theme and plugin. Available many filter.

* Workflow added

## Widgets List
* Counter

