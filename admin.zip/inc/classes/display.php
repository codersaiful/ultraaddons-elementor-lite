<?php
namespace UltraAddons\Core;


/**
 * Description of display
 *
 * @author CODES
 */
class display {
    //put your code here
}
