<?php
//For Pro plugin, not for free version
define( 'ULTRA_ADDONS_PRO_VERSION', '1.0.0' );