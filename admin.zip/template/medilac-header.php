<?php

/**
 * Custom Footer file for Medilac
 * by UltraAddons
 * 
 * @package UltraAddons
 * @category Core
 * 
 * @since 1.0.0.10
 */
