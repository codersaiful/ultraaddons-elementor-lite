<?php

/**
 * Custom Header file for Medilac Theme
 * by UltraAddons
 * 
 * @package UltraAddons
 * @category Core
 * 
 * @since 1.0.0.10
 */
