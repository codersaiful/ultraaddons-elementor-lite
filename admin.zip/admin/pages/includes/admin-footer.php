<?php
defined( 'ABSPATH' ) || die();

?>
<div class="ultraddons-admin-footer">
    <?php
    do_action( 'ultraaddons/admin/footer' );
    ?>
</div>
        </div> <!-- /.ultraaddons-dashboard-area -->
</div><!-- /.ultraaddons-admin-wrapper -->