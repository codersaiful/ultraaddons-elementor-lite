<?php
/**
 * Silence is Golden
 */

